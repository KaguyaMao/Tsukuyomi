import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

const OptionSchema = Type.Object({
	label: Type.String({ description: "Short choice label" }),
	description: Type.Optional(Type.String({ description: "Consequence or tradeoff" })),
	value: Type.Optional(Type.String({ description: "Stable returned value; defaults to label" })),
	recommended: Type.Optional(Type.Boolean({ description: "Mark the suggested choice" })),
});
const QuestionSchema = Type.Object({
	id: Type.String({ description: "Stable answer key" }),
	header: Type.Optional(Type.String({ description: "Short category, at most 12 characters when practical" })),
	question: Type.String({ description: "One concrete question" }),
	options: Type.Optional(Type.Array(OptionSchema, { description: "Two to four mutually exclusive choices" })),
	allowOther: Type.Optional(Type.Boolean({ description: "Allow a free-form response; defaults to true" })),
});

export function registerQuestionnaire(pi: ExtensionAPI) {
	pi.registerTool({
		name: "questionnaire",
		label: "Ask user / 询问用户",
		description: "Ask the user up to three concise clarification questions. Prefer 2–4 concrete options, put the recommended option first, explain tradeoffs, and allow a custom answer. Use only when the answer materially changes the plan.",
		parameters: Type.Object({ questions: Type.Array(QuestionSchema, { minItems: 1, maxItems: 3 }) }),
		async execute(_id, params, signal, _update, ctx) {
			if (!ctx.hasUI) return { content: [{ type: "text" as const, text: "Cannot ask questions: interactive UI is unavailable." }], details: { cancelled: true }, isError: true };
			const answers: Array<{ id: string; value: string; label: string; custom: boolean }> = [];
			for (const question of params.questions.slice(0, 3)) {
				if (signal?.aborted) throw new Error("Questionnaire cancelled");
				const options = (question.options || []).slice(0, 4);
				const labels = options.map((option) => `${option.recommended ? "★ " : ""}${option.label}${option.description ? ` — ${option.description}` : ""}`);
				const allowOther = question.allowOther !== false;
				const other = "Other / 其他（输入自定义回答）";
				if (!labels.length && !allowOther) throw new Error(`Question ${question.id} has no answer options`);
				let selected: string | undefined;
				if (labels.length) selected = await ctx.ui.select(`${question.header ? `${question.header} · ` : ""}${question.question}`, allowOther ? [...labels, other] : labels);
				else selected = other;
				if (!selected) return { content: [{ type: "text" as const, text: "User cancelled the questionnaire." }], details: { questions: params.questions, answers, cancelled: true } };
				if (selected === other) {
					const custom = await ctx.ui.input(question.question, "Type your answer");
					if (custom === undefined) return { content: [{ type: "text" as const, text: "User cancelled the questionnaire." }], details: { questions: params.questions, answers, cancelled: true } };
					answers.push({ id: question.id, value: custom.trim(), label: custom.trim(), custom: true });
				} else {
					const index = labels.indexOf(selected);
					const option = options[index];
					answers.push({ id: question.id, value: option.value || option.label, label: option.label, custom: false });
				}
			}
			return {
				content: [{ type: "text" as const, text: answers.map((answer) => `${answer.id}: ${answer.value}`).join("\n") }],
				details: { questions: params.questions, answers, cancelled: false },
			};
		},
	});
}
